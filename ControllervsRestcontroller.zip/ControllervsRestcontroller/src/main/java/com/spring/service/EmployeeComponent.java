package com.spring.service;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.config.ConfigurableBeanFactory;
import org.springframework.context.annotation.Scope;
import org.springframework.stereotype.Component;

import com.google.gson.Gson;
import com.spring.bean.Employee;

@Component("e1")
@Scope(ConfigurableBeanFactory.SCOPE_PROTOTYPE)
public class EmployeeComponent {
	
	@Autowired
	Employee e;
	
	int a=0;
	
	public String display(String name,String occupation){
		e.setName(name);
		e.setOccupation(occupation);
		System.out.println(e);
		a++;
		e.setId(a);
		System.out.println(a);
        Gson gson = new Gson();
        String json = gson.toJson(e);
        return json;
	}
	
	public Employee print(String name,String occupation){
		e.setName(name);
		e.setOccupation(occupation);
		System.out.println(e);
		a++;
		e.setId(a);
		System.out.println(a);
        /*Gson gson = new Gson();
        String json = gson.toJson(e);*/
        return e;
	}
}
