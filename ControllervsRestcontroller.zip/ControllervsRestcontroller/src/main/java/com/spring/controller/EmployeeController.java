package com.spring.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.ResponseBody;

import com.spring.bean.Employee;
import com.spring.service.EmployeeComponent;

@Controller
@RequestMapping("")
public class EmployeeController {
	
	@Autowired
	@Qualifier("e1")
	EmployeeComponent e1;
	
	@RequestMapping(value = "employee/{name}/{occupation}", method = RequestMethod.GET, produces = "application/json")
    public @ResponseBody String getEmployeeInJSON(@PathVariable String name,@PathVariable String occupation) {
       return e1.display(name, occupation);
    }

}
