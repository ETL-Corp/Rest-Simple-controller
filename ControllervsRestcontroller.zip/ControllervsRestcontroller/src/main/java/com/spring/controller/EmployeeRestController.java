package com.spring.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.bind.annotation.RestController;

import com.spring.bean.Employee;
import com.spring.service.EmployeeComponent;

@RestController
@RequestMapping("/rest")
public class EmployeeRestController {
	
	@Autowired
	@Qualifier("e1")
	EmployeeComponent e1;
	
	@RequestMapping(value = "/rest/{name}/{occupation}", method = RequestMethod.GET, produces = "application/json")
    public Employee getEmployeeInRestJSON(@PathVariable String name,@PathVariable String occupation) {
		  return e1.print(name, occupation);
    }

}
